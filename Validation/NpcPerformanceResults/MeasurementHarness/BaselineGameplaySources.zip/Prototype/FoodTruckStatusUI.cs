using UnityEngine;
using UnityEngine.UI;

public class FoodTruckStatusUI : MonoBehaviour
{
    [SerializeField] private FoodTruckHealth truck;
    [SerializeField] private Slider hpBar;
    [SerializeField] private Text hpText;
    public void Configure(FoodTruckHealth target, Slider bar, Text label)
    {
        if (isActiveAndEnabled && truck != null) truck.HealthChanged -= Refresh;
        truck = target; hpBar = bar; hpText = label;
        if (isActiveAndEnabled && truck != null) truck.HealthChanged += Refresh;
        Refresh();
    }
    private void OnEnable()
    {
        if (truck == null || hpBar == null)
        {
            if (Application.isPlaying)
            { Debug.LogError("FoodTruckStatusUI needs Truck and HP Slider references.", this); enabled = false; }
            return;
        }
        truck.HealthChanged += Refresh;
        Refresh();
    }
    private void OnDisable() { if (truck != null) truck.HealthChanged -= Refresh; }
    private void LateUpdate() => Refresh();
    private void Refresh()
    {
        if (truck == null || hpBar == null) return;
        hpBar.SetValueWithoutNotify(truck.MaxHP > 0f ? truck.CurrentHP / truck.MaxHP : 0f);
        if (hpText != null) hpText.text = $"TRUCK HP {truck.CurrentHP:0.#} / {truck.MaxHP:0.#}";
    }
}

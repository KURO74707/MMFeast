using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private EnemySimpleAI enemyPrefab;
    [SerializeField] private Customer customerPrefab;
    [SerializeField] private GlobalGameSettings settings;
    [SerializeField] private Transform player;
    [SerializeField] private FoodTruckHealth foodTruck;
    [SerializeField] private Transform[] spawnPoints;
    private readonly List<GameObject> aliveEnemies = new List<GameObject>();
    private int spawnedCount;
    private float lastSpawnTime;
    private bool hasSpawned;
    public void Configure(EnemySimpleAI prefab, Transform target, Transform[] points)
    { enemyPrefab = prefab; player = target; spawnPoints = points; }
    public void ConfigureCustomers(Customer prefab) => customerPrefab = prefab;
    public void ConfigureFoodTruck(FoodTruckHealth truck) => foodTruck = truck;

    private void Start()
    {
        if (!GlobalGameSettings.Require(this, settings)) return;
        if (enemyPrefab == null || player == null || spawnPoints == null || spawnPoints.Length == 0)
        {
            Debug.LogError("EnemySpawner needs enemyPrefab, player and spawnPoints.", this);
            enabled = false;
        }
    }

    private void Update()
    {
        if (!GlobalGameSettings.Require(this, settings)) return;
        aliveEnemies.RemoveAll(entity => entity == null ||
            (entity.TryGetComponent(out EnemyHealth zombie) && zombie.IsDead) ||
            (entity.TryGetComponent(out Customer customer) && (customer.IsPurified || customer.IsDead)));
        if ((hasSpawned && Time.time - lastSpawnTime < settings.SpawnInterval) || aliveEnemies.Count >= settings.MaximumAliveEnemies) return;
        Transform point = spawnPoints[Random.Range(0, spawnPoints.Length)];
        if (point == null) return;
        lastSpawnTime = Time.time;
        hasSpawned = true;
        spawnedCount++;
        if (customerPrefab != null && spawnedCount % settings.CustomerEveryNthSpawn == 0)
        {
            Customer customer = Instantiate(customerPrefab, point.position, Quaternion.identity);
            if (customer.TryGetComponent(out EnemySimpleAI movement)) movement.SetTarget(player);
            aliveEnemies.Add(customer.gameObject);
            Debug.Log("Customer spawned", customer);
        }
        else
        {
            EnemySimpleAI enemy = Instantiate(enemyPrefab, point.position, Quaternion.identity);
            enemy.SetTarget(player);
            enemy.SetFoodTruckTarget(foodTruck);
            aliveEnemies.Add(enemy.gameObject);
            Debug.Log("Zombie spawned", enemy);
        }
    }
}
